import os
from flask import Flask
from dotenv import load_dotenv

def create_app():
    load_dotenv()
    app = Flask(__name__)
    key = os.getenv('SECRET_KEY')
    if not key or key == 'genera-una-clave-aleatoria':
        raise RuntimeError('Configura SECRET_KEY')
    app.secret_key = key
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', MAX_CONTENT_LENGTH=3*1024*1024)
    from .routes import web
    app.register_blueprint(web)
    return app
