import os
import libsql_experimental as libsql
from contextlib import contextmanager

@contextmanager
def database():
    url, token = os.getenv('TURSO_URL'), os.getenv('TURSO_TOKEN')
    if not url or not token:
        raise RuntimeError('Faltan las variables TURSO_URL o TURSO_TOKEN')
    conn = libsql.connect('huellitas_v2.db', sync_url=url, auth_token=token)
    try:
        conn.sync()
        yield conn
    finally:
        conn.close()

def all_rows(conn,sql,args=()):
    cursor=conn.execute(sql,args)
    names=[d[0] for d in cursor.description]
    return [dict(zip(names,row)) for row in cursor.fetchall()]

def one(conn,sql,args=()):
    rows=all_rows(conn,sql,args)
    return rows[0] if rows else None

def save(conn):
    conn.commit()
    conn.sync()
