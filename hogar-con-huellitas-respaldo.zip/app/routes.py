import secrets
from functools import wraps
from io import BytesIO
from PIL import Image, UnidentifiedImageError
import os
import cloudinary
import cloudinary.uploader
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash
from .db import database,all_rows,one,save

web=Blueprint('web', __name__)

def csrf_token():
    if '_csrf' not in session:
        session['_csrf']=secrets.token_urlsafe(32)
    return session['_csrf']

@web.app_context_processor
def inject_csrf():
    return {'csrf_token':csrf_token}

def check_csrf():
    if not secrets.compare_digest(session.get('_csrf',''), request.form.get('_csrf','')):
        abort(400, 'Formulario expirado; vuelve a intentarlo.')

def login_required(func):
    @wraps(func)
    def wrapper(*args,**kwargs):
        if not session.get('user_id'):
            flash('Inicia sesión para continuar.','info')
            return redirect(url_for('web.login'))
        return func(*args,**kwargs)
    return wrapper

@web.get('/')
def home():
    with database() as db:
        pets=all_rows(db,"SELECT * FROM mascotas WHERE estado='disponible' ORDER BY id DESC LIMIT 3")
    return render_template('index.html',pets=pets)

@web.get('/mascotas')
def pets():
    species=request.args.get('especie','')
    if species not in ('','perro','gato'): species=''
    with database() as db:
        pets=all_rows(db,"SELECT * FROM mascotas WHERE estado='disponible' AND (?='' OR especie=?) ORDER BY id DESC",(species,species))
    return render_template('mascotas.html',pets=pets,species=species)

@web.get('/mascotas/<int:pet_id>')
def pet_detail(pet_id):
    with database() as db:
        pet=one(db,'SELECT * FROM mascotas WHERE id=?',(pet_id,))
    if not pet: abort(404)
    return render_template('detalle.html',pet=pet)

@web.route('/registro',methods=['GET','POST'])
def register():
    if request.method=='POST':
        check_csrf()
        name=request.form.get('nombre','').strip()
        email=request.form.get('email','').strip().lower()
        password=request.form.get('password','')
        if not name or len(name)>80 or '@' not in email or len(email)>254 or len(password)<8 or len(password)>128:
            flash('Completa tus datos y usa una contraseña de 8 a 128 caracteres.','error')
        else:
            with database() as db:
                if one(db,'SELECT id FROM usuarios WHERE email=?',(email,)):
                    flash('Ya existe una cuenta con ese correo.','error')
                else:
                    try:
                        db.execute('INSERT INTO usuarios(nombre,email,password_hash) VALUES(?,?,?)',(name,email,generate_password_hash(password)))
                        save(db)
                        flash('Cuenta creada. Ahora inicia sesión.','success')
                        return redirect(url_for('web.login'))
                    except Exception:
                        flash('No se pudo crear la cuenta. Intenta de nuevo.','error')
    return render_template('registro.html')

@web.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        check_csrf()
        email=request.form.get('email','').strip().lower()
        password=request.form.get('password','')
        with database() as db:
            user=one(db,'SELECT * FROM usuarios WHERE email=?',(email,))
        if not user or not check_password_hash(user['password_hash'],password):
            flash('Correo o contraseña incorrectos.','error')
        else:
            session.clear()
            session['user_id']=user['id']
            session['user_name']=user['nombre']
            flash('¡Bienvenid@ a Hogar con Huellitas!','success')
            return redirect(url_for('web.panel'))
    return render_template('login.html')

@web.post('/salir')
@login_required
def logout():
    check_csrf()
    session.clear()
    return redirect(url_for('web.home'))

@web.route('/publicar',methods=['GET','POST'])
@login_required
def publish():
    if request.method=='POST':
        check_csrf()
        data={key:request.form.get(key,'').strip() for key in ('nombre','especie','edad','tamano','ubicacion','descripcion')}
        photo=request.files.get('foto')
        if any(not data[k] for k in ('nombre','especie','edad','tamano','ubicacion','descripcion')) or data['especie'] not in ('perro','gato') or data['tamano'] not in ('pequeño','mediano','grande'):
            flash('Completa todos los datos de la mascota.','error')
        elif len(data['nombre'])>80 or len(data['edad'])>60 or len(data['ubicacion'])>120 or len(data['descripcion'])>1500:
            flash('Algún campo es demasiado largo.','error')
        elif not photo or not photo.filename:
            flash('Elige una fotografía de tu mascota.','error')
        elif not all(os.getenv(key) for key in ('CLOUDINARY_CLOUD_NAME','CLOUDINARY_API_KEY','CLOUDINARY_API_SECRET')):
            flash('Falta configurar Cloudinary para guardar fotos.','error')
        else:
            raw=photo.read()
            try:
                if len(raw)>2*1024*1024:
                    raise ValueError('La foto debe pesar menos de 2 MB.')
                with Image.open(BytesIO(raw)) as img:
                    if img.format not in ('PNG','JPEG','WEBP'):
                        raise ValueError('Usa JPG, PNG o WebP.')
                    img.verify()
                cloudinary.config(
                    cloud_name=os.environ['CLOUDINARY_CLOUD_NAME'],
                    api_key=os.environ['CLOUDINARY_API_KEY'],
                    api_secret=os.environ['CLOUDINARY_API_SECRET'],secure=True
                )
                uploaded=cloudinary.uploader.upload(BytesIO(raw),resource_type='image',folder='hogar_con_huellitas/mascotas',
                    transformation={'width':1200,'height':1200,'crop':'limit'},overwrite=False)
                image_url=uploaded['secure_url']
                with database() as db:
                    db.execute("""INSERT INTO mascotas(usuario_id,nombre,especie,edad,tamano,ubicacion,descripcion,foto_url)
                                  VALUES(?,?,?,?,?,?,?,?)""",(session['user_id'],data['nombre'],data['especie'],data['edad'],data['tamano'],data['ubicacion'],data['descripcion'],image_url))
                    save(db)
                flash('¡Mascota publicada con su foto!','success')
                return redirect(url_for('web.pets'))
            except (ValueError,UnidentifiedImageError) as exc:
                flash(str(exc) or 'El archivo no es una imagen válida.','error')
            except Exception:
                flash('No se pudo subir la foto o guardar la mascota. Inténtalo nuevamente.','error')
    return render_template('publicar.html')

@web.route('/adoptar/<int:pet_id>',methods=['GET','POST'])
@login_required
def adopt(pet_id):
    with database() as db:
        pet=one(db,'SELECT * FROM mascotas WHERE id=?',(pet_id,))
    if not pet: abort(404)
    if pet['usuario_id']==session['user_id']:
        flash('No puedes solicitar adoptar tu propia mascota.','error')
        return redirect(url_for('web.pet_detail',pet_id=pet_id))
    if pet['estado']!='disponible':
        flash('Esta mascota ya no está disponible.','error')
        return redirect(url_for('web.pet_detail',pet_id=pet_id))
    if request.method=='POST':
        check_csrf()
        msg=request.form.get('mensaje','').strip()
        if len(msg)<15 or len(msg)>1500:
            flash('Cuéntanos un poco más (15 a 1500 caracteres).','error')
        else:
            with database() as db:
                if one(db,"SELECT id FROM solicitudes WHERE mascota_id=? AND solicitante_id=? AND estado='pendiente'",(pet_id,session['user_id'])):
                    flash('Ya tienes una solicitud pendiente para esta mascota.','info')
                else:
                    try:
                        db.execute('INSERT INTO solicitudes(mascota_id,solicitante_id,mensaje) VALUES(?,?,?)',(pet_id,session['user_id'],msg))
                        save(db)
                        flash('¡Solicitud enviada! El responsable podrá revisarla.','success')
                        return redirect(url_for('web.panel'))
                    except Exception:
                        flash('No se pudo enviar la solicitud.','error')
    return render_template('adoptar.html',pet=pet)

@web.get('/panel')
@login_required
def panel():
    with database() as db:
        own=all_rows(db,'SELECT * FROM mascotas WHERE usuario_id=? ORDER BY id DESC',(session['user_id'],))
        sent=all_rows(db,"""SELECT s.*,m.nombre AS mascota_nombre FROM solicitudes s
            JOIN mascotas m ON s.mascota_id=m.id WHERE s.solicitante_id=? ORDER BY s.id DESC""",(session['user_id'],))
        received=all_rows(db,"""SELECT s.*,m.nombre AS mascota_nombre,u.nombre AS solicitante_nombre
            FROM solicitudes s JOIN mascotas m ON m.id=s.mascota_id
            JOIN usuarios u ON u.id=s.solicitante_id
            WHERE m.usuario_id=? ORDER BY s.id DESC""",(session['user_id'],))
    return render_template('panel.html',own=own,sent=sent,received=received)

@web.post('/solicitudes/<int:request_id>/<decision>')
@login_required
def decide(request_id,decision):
    check_csrf()
    if decision not in ('aprobada','rechazada'): abort(404)
    with database() as db:
        req=one(db,"""SELECT s.*,m.usuario_id AS owner_id,m.estado AS pet_status
            FROM solicitudes s JOIN mascotas m ON m.id=s.mascota_id WHERE s.id=?""",(request_id,))
        if not req or req['owner_id']!=session['user_id']: abort(403)
        if req['estado']!='pendiente' or req['pet_status']!='disponible':
            flash('La solicitud ya no se puede modificar.','info')
        else:
            db.execute("UPDATE solicitudes SET estado=? WHERE id=? AND estado='pendiente'",(decision,request_id))
            if decision=='aprobada':
                db.execute("UPDATE mascotas SET estado='adoptado' WHERE id=? AND estado='disponible'",(req['mascota_id'],))
                db.execute("UPDATE solicitudes SET estado='rechazada' WHERE mascota_id=? AND id<>? AND estado='pendiente'",(req['mascota_id'],request_id))
            save(db)
            flash('Solicitud actualizada correctamente.','success')
    return redirect(url_for('web.panel'))
